<?php
require_once __DIR__ . '/client.php';
require_once __DIR__ . '/object.php';
require_once __DIR__ . '/file.php';
require_once __DIR__ . '/folder.php';
