<?php
/**
 * Load all the files for Advanced form block.
 *
 * @package Kadence Blocks.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once KBP_PATH . 'includes/advanced-form/advanced-form-submit-actions.php';
require_once KBP_PATH . 'includes/advanced-form/kbp-advanced-form-analytics.php';
require_once KBP_PATH . 'includes/advanced-form/advanced-form-ajax.php';
