<?php

namespace KadenceWP\KadenceBlocksPro\Uplink;

class Helper {
	/**
	 * @var string Helper data
	 */
	const DATA = '';

}